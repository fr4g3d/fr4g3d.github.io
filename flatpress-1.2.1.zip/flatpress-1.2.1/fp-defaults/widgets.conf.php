<?php

  $fp_widgets = array (
	
	// to disable put // or # before the plugin name
  	// remove it to enable :)
  	
  
  'top' => 
  array (
    // (no widgets)
  ),

  // Left side widgets. Put here blocks which will appear 
  // on the left side
  // (Theme dependant)

  'left' => 
  array (
    // (no widgets)
  ),


  // Right side widgets
  'right' => 
  array (
    'adminarea',
    'blockparser:menu',
    'categories',
    'archives',
    //'calendar', // quite time consuming, not really recommended
    'lastentries',
    // 'lastcomments',
    'searchbox',
  ),
  
  'bottom' => 
  array (
    // (no widgets)
  ),

  
);

?>
