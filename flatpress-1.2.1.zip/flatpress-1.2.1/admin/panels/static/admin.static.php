<?php

/**
 * edit entry panel
 *
 * Type:     
 * Name:     
 * Date:     
 * Purpose:  
 * Input:
 *         
 * @author NoWhereMan <real_nowhereman at users dot sf dot com>
 *
 */
 	
	
	class admin_static extends AdminPanel {
		
		var $panelname = "static";
		var $actions = array(	
					'list' => true,
					'delete' => false,
					'write' => true,
					);
		var $defaultaction = 'list';
			
	}
 	
	
	
	

?>
