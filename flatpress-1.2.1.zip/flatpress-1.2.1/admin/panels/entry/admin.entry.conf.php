<?php

/**
 * edit entry panel
 *
 * Type:     
 * Name:     
 * Date:     
 * Purpose:  
 * Input:
 *         
 * @author NoWhereMan <real_nowhereman at users dot sf dot com>
 *
 */
 
 
 $admin_entry_sections = array(
 	'list',
	'new',
	'edit',
	'delete',
	'comms',
	'commsdel'
 );

?>
