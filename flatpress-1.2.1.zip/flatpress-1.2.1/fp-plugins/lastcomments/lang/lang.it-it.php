<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> 'Ultimi',
		'comments'			=> 'commenti',
		'no_comments'		=> 'Nessun commento',
		'no_new_comments'	=> 'Nessun nuovo commento'
		
	);

?>