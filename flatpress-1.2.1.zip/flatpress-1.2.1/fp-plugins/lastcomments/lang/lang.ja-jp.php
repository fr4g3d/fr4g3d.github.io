<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> '最近のコメント:',
		'comments'			=> 'コメント',
		'no_comments'		=> 'ありません',
		'no_new_comments'	=> '最近のコメント'
		
	);

?>