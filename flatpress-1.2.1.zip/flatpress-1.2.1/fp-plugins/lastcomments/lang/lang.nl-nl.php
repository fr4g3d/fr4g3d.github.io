<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> 'Laatste',
		'comments'			=> 'Opmerkingen',
		'no_comments'		=> 'Geen opmerkingen',
		'no_new_comments'	=> 'Geen nieuwe opmerkingen'
		
	);

?>