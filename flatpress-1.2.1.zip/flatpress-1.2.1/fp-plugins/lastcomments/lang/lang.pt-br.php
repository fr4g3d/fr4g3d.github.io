<?php
//Terminado - 15 de fevereiro de 2020.

	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'			=> 'Úlitimo ',
		'comments'		=> 'comentários',
		'no_comments'		=> 'Sem comentário',
		'no_new_comments'	=> 'Sem novos comentários'
		
	);

?>