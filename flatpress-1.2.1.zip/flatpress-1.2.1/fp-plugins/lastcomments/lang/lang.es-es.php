<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'			=> 'Último',
		'comments'		=> 'Comentario,
		'no_comments'		=> 'Sin comentarios',
		'no_new_comments'	=> 'Sin comentarios nuevos'
		
	);

?>