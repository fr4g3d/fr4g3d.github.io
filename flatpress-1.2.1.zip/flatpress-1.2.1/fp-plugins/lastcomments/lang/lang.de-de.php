<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> 'Letzte',
		'comments'			=> 'Kommentare',
		'no_comments'		=> 'Keine Kommentare',
		'no_new_comments'	=> 'Keine neuen Kommentare'
		
	);

?>
