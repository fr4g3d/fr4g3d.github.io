<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> 'Τελευταία',
		'comments'			=> 'σχόλια',
		'no_comments'		=> 'Κανένα σχόλιο',
		'no_new_comments'	=> 'Κανένα νέο σχόλιο'
		
	);

?>
