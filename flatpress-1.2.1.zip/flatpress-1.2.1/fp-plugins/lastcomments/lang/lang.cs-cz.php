<?php
	// cimangi Aggiunta traduzione stringhe
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> 'Poslední',
		'comments'			=> 'Komentáře',
		'no_comments'		=> 'Žádný komentář',
		'no_new_comments'	=> 'Žádný nový komentář'
		
	);

?>