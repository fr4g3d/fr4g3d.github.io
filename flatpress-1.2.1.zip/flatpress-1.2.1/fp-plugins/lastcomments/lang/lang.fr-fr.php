<?php
	
	$lang['plugin']['lastcomments'] = array(
		
		'last'				=> 'Dernier(s)',
		'comments'			=> 'commentaires',
		'no_comments'		=> 'Pas de commentaires',
		'no_new_comments'	=> 'Pas de nouveau commentaires'
		
	);

?>