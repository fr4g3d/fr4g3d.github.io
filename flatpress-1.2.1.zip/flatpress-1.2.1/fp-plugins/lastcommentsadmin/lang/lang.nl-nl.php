<?php
	$lang['plugin']['lastcommentsadmin ']['errors'] = array (
		-1	=> 'API-sleutel niet ingesteld. Open de plug-in om uw API-sleutel in te stellen. Registreer in <a href="http://wordpress.com">Wordpress.com</a> om er een te krijgen'
	);

	$lang['admin']['plugin']['submenu']['lastcommentsadmin'] = 'Laatste Opmerkingen beheerder';

	$lang['admin']['plugin']['lastcommentsadmin'] = array(
		'head'		=> 'Beheerder laatste opmerkingen',
		'description'=>'Cache laatste opmerking wissen en opnieuw maken ',
		'clear'	=> 'Cache wissen',
		'cleardescription' => 'Cachebestand laatste opmerking verwijderen. Er wordt een nieuwe bestandscache gemaakt wanneer een nieuwe opmerking wordt geplaatst.',
		'rebuild' => 'Cache opnieuw opbouwen',
		'rebuilddescription' => 'Cachebestand laatste opmerking opnieuw opbouwen. Het kan heel lang duren. Kan helemaal niet werken. Kan uw muis opbranden!',
	);
	$lang['admin']['plugin']['lastcommentsadmin']['msgs'] = array(
		1		=> 'Cache verwijderd',
		2		=> 'Cache opnieuw opgebouwd!',
		-1		=> 'Error!',
		-2	   =>  'Deze plugin vereist LastComments plugin!'
	);
	

?>