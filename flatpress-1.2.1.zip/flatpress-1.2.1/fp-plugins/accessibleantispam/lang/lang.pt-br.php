<?php
//Terminado - 15 de fevereiro de 2020.

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> 'Para ajudar a eliminar ataques de spam automatizados, precisamos pedir que você prove que é humano. O que é ',
		
	'sum'		=> '%s mais %s ?',
	'sub'		=> '%1$s menos %2$s ?',
	'prod'		=> '%s vezes %s ?',
		
	'error'		=> 'Desculpe, você deu a resposta errada. Por favor, tente novamente.'
	
	);

