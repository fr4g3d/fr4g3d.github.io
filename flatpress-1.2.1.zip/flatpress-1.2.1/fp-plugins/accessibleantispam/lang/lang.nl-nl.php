<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> 'Om geautomatiseerde spam aanvallen te helpen elimineren '.
		'moeten wij je vragen om te bewijzen dat je een mens bent. Wat is ',
		
	'sum'		=> '%s plus %s ?',
	'sub'		=> '%2$s afgetrokken van %1$s ?',
	'prod'		=> '%s keer %s ?',
		
	'error'		=> 'Sorry, je hebt het verkeerde antwoord gegeven. Probeer het alstublieft opnieuw.'
	
	);

