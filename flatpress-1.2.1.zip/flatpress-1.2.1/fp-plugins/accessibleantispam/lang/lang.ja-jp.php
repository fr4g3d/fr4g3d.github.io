<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> '次の計算の答えを記入してください。',
		
	'sum'		=> '%s ＋ %s ',
	'sub'		=> '%1$s － %2$s ',
	'prod'		=> '%s × %s ',
		
	'error'		=> '計算が違っていたようです。もう一度、解答してください。'
	
	);

