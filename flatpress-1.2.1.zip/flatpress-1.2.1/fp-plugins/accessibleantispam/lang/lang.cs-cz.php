<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> 'Jako prevence před zneužitím komentovacího systému je třeba k Vašemu komentáři připojit výsledek jednoduché matematické operace: ',
		
	'sum'		=> '%s plus %s ?',
	'sub'		=> '%2$s odečíst od %1$s ?',
	'prod'		=> '%s krát %s ?',
		
	'error'		=> 'Výsledek je nesprávný. Prosím, zkuste to znovu.'
	
	);

