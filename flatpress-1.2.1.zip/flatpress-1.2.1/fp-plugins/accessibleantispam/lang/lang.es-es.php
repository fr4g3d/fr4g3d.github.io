<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> 'Para ayudar a eliminar los ataques de spam automatizados '.
		'debemos pedirle que demuestre que es humano. Que es ',
		
	'sum'		=> '%s más %s ?',
	'sub'		=> '%2$s extraído de %1$s ?',
	'prod'		=> '%s veces %s ?',
		
	'error'		=> 'Lo siento, diste una respuesta incorrecta. Inténtalo de nuevo.'
	
	);

