<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> 'Afin d\'&eacute;liminer le spam '.
		'vous devez prouver que vous &ecirc;tes un humain. Combien font ',
		
	'sum'		=> '%s plus %s ?',
	'sub'		=> '%2$s moins %1$s ?',
	'prod'		=> '%s fois %s ?',
		
	'error'		=> 'Oups! Votre r&eacute;ponse est incorrecte. Essayez de nouveau.'
	
	);

