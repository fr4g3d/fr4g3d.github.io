<?php

	$lang['plugin']['accessibleantispam'] = array(
		
		'prefix'	=> 'Um Spammern den Missbrauch des Kommentarsystems zu erschweren,'.
                                  ' fragen wir nach dem Ergebnis einer einfachen mathematischen Operation, '.
			         'bitte ',
		
		'sum'		=> 'addiere %s zu %s',
		'sub'		=> 'subtrahiere %2$s von %1$s',
		'prod'		=> 'multipliziere %s und %s',
		
		'error'		=> 'Das Ergebnis ist nicht korrekt, bitte erneut versuchen.'
	
	);

?>
