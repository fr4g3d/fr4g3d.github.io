<?php

$lang['plugin']['accessibleantispam'] = array(
		
	'prefix'	=> 'Per fare in modo di aiutarti ad eliminare gli attacchi di spam automatici '.
		'dobbiamo chiederti di provare che sei una persona vera. Quanto fa ',
		
	'sum'		=> '%s più %s ?',
	'sub'		=> '%2$s meno %1$s ?',
	'prod'		=> '%s per %s ?',
		
	'error'		=> 'Spiacenti, hai sbagliato. Riprova.'
	
	);

