<?php

	$lang['plugin']['categories'] = array(
		
		'subject'	=> 'Cat&eacute;gories'
	
	);

?>