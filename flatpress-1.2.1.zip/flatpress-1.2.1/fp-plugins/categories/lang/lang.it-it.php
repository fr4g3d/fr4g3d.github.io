<?php

	$lang['plugin']['categories'] = array(
		
		'subject'	=> 'Categorie'
	
	);

?>