<?php
//Terminado 15 de fevereiro de 2020.

	$lang['plugin']['categories'] = array(
		
		'subject'	=> 'Categorias'
	
	);

?>