<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Área de administração',
		'welcome'		=> 'Bem vindo, ',
		'admin_panel'	=> 'Painel do administrador',
		'add_entry'		=> 'Crie um post',
		'add_static'	=> 'Crie uma página estável',
		'logout'		=> 'Sair'
	
	);

?>