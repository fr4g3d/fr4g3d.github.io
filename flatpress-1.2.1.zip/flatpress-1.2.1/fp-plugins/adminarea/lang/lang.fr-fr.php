<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Administration',
		'welcome'		=> 'Accueil',
		'admin_panel'	=> 'Panneau de contr&ocirc;le',
		'add_entry'		=> 'Ajouter un billet',
		'add_static'	=> 'Ajouter une page statique',
		'logout'		=> 'D&eacute;connexion'
	
	);

?>