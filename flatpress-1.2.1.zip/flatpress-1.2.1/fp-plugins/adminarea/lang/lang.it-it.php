<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Pannello di controllo',
		'welcome'		=> 'Pagina principale, ',
		'admin_panel'	=> 'Pannello di controllo',
		'add_entry'		=> 'Aggiungi articolo',
		'add_static'	=> 'Aggiungi pagina statica',
		'logout'		=> 'Disconnettiti'
	
	);

?>