<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Administrátorská zóna',
		'welcome'		=> 'Vítejte, ',
		'admin_panel'	=> 'Správa nastavení',
		'add_entry'		=> 'Přidej příspěvek',
		'add_static'	=> 'Přidať statickou stránku',
		'logout'		=> 'Odhlásit'
	
	);

?>