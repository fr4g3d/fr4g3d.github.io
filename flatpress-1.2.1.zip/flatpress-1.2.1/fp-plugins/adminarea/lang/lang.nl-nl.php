<?php
$lang ['plugin'] ['adminarea'] = array(

	'subject' 	=> 'Administratie',
	'welcome' 	=> 'Welkom thuis, ',
	'admin_panel' 	=> 'Administratie gebied',
	'add_entry' 	=> 'Vermelding toevoegen',
	'add_static' 	=> 'Statische pagina toevoegen',
	'logout' 	=> 'Uitloggen'
);