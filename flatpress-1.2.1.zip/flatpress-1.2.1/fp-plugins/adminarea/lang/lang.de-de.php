<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Administration',
		'welcome'		=> 'Willkommen ',
		'admin_panel'	=> 'Kontrollzentrum',
		'add_entry'		=> 'Neuer Beitrag',
		'add_static'	=> 'Neue statische Seite',
		'logout'		=> 'Abmelden'
	
	);

?>
