<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Área de administración',
		'welcome'		=> 'Bienvenido ',
		'admin_panel'		=> 'Panel de administrador',
		'add_entry'		=> 'Añadir entrada',
		'add_static'		=> 'Añadir estática',
		'logout'		=> 'Cerrar sesión'
	
	);

?>