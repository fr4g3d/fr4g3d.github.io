<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> 'Διαχείριση',
		'welcome'		=> 'Καλως ήρθατε, ',
		'admin_panel'	=> 'Πίνακας ελέγχου',
		'add_entry'		=> 'Προσθήκη καταχώρησης',
		'add_static'	=> 'Προσθήκη στατικής σελίδας',
		'logout'		=> 'Αποσύνδεση'
	
	);

?>
