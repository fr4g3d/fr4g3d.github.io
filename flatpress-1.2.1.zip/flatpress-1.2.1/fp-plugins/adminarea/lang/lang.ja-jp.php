<?php

	$lang['plugin']['adminarea'] = array(
		
		'subject'		=> '管理者用',
		'welcome'		=> 'ホーム, ',
		'admin_panel'	=> '管理者用ページへ',
		'add_entry'		=> 'ブログ記事の新規作成',
		'add_static'	=> '固定ページの新規作成',
		'logout'		=> 'ログアウト'
	
	);

?>
