<?php
$lang ['plugin'] ['adminarea'] = array(

	'subject' => 'Admin',
	'welcome' => 'Welcome home, ',
	'admin_panel' => 'Admin area',
	'add_entry' => 'Add entry',
	'add_static' => 'Add static',
	'logout' => 'Logout'
);