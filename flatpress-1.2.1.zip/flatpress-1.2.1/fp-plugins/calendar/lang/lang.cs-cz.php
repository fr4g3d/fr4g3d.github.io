<?php

	$lang['plugin']['calendar'] = array(
		
		'subject'	=> 'Kalendář'
	
	);

?>