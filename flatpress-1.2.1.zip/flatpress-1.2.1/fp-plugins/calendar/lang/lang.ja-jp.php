<?php

	$lang['plugin']['calendar'] = array(
		
		'subject'	=> 'カレンダー'
	
	);

?>