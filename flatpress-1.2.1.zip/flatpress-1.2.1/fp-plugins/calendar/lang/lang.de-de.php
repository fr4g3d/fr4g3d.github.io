<?php

	$lang['plugin']['calendar'] = array(
		
		'subject'	=> 'Kalender'
	
	);

?>
