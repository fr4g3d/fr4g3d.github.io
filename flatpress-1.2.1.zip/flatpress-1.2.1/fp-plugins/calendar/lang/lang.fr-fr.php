<?php

	$lang['plugin']['calendar'] = array(
		
		'subject'	=> 'Calendrier'
	
	);

?>