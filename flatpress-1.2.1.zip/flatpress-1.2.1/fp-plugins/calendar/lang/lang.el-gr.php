<?php

	$lang['plugin']['calendar'] = array(
		
		'subject'	=> 'Ημερολόγιο'
	
	);

?>
