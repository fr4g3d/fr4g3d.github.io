<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Poslední ',
		'subject_after_count'	=> ' příspěvky',
		'edit'			=> 'Upravit',
		'add_entry'		=> 'Přidat příspěvek',
		'no_entries'	=> 'Žádný příspěvek'
	);

?>
