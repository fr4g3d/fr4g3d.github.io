<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Últimas ',
		'subject_after_count'	=> ' Entradas',
		'edit'			=> 'editar',
		'add_entry'		=> 'Agregar entrada',
		'no_entries'		=> 'No hay entradas'
	
	
	);

?>
