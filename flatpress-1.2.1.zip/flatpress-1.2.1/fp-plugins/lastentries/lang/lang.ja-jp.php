<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> '最近の記事: ',
		'subject_after_count'	=> '本',
		'edit'			=> '編集',
		'add_entry'		=> '記事の新規作成',
		'no_entries'	=> '記事がありません'
	
	
	);

?>
