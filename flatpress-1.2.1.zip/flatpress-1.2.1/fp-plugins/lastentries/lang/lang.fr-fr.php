<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Dernier(s) ',
		'subject_after_count'	=> ' billets',
		'edit'			=> '&Eacute;diter',
		'add_entry'		=> 'Ajouter un billet',
		'no_entries'	=> 'Pas de billets'
	
	
	);

?>
