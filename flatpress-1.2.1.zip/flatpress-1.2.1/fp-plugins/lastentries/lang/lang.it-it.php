<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Ultimi ',
		'subject_after_count'	=> ' articoli',
		'edit'			=> 'modifica',
		'add_entry'		=> 'Aggiungi articolo',
		'no_entries'	=> 'Nessun articolo'
	
	
	);

?>
