<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Die letzten ',
		'subject_after_count'	=> ' Einträge',
		'edit'					=> 'bearbeiten',
		'add_entry'		=> 'Eintrag hinzufügen',
		'no_entries'	=> 'Keine Einträge'

	
	);

?>
