<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Laatste ',
		'subject_after_count'	=> ' Vermeldingen',
		'edit'			=> 'Bewerk ',
		'add_entry'		=> 'Voeg vermelding toe',
		'no_entries'		=> 'Geen vermeldingen'
	
	
	);

?>
