<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Úlitimo ',
		'subject_after_count'	=> ' posts',
		'edit'			=> 'Edite',
		'add_entry'		=> 'Adicione post',
		'no_entries'	=> 'Sem Posts'
	
	
	);

?>
