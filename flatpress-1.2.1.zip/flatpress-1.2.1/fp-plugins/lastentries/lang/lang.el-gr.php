<?php

	$lang['plugin']['lastentries'] = array(
		
		'subject_before_count'	=> 'Τελευταίες ',
		'subject_after_count'	=> ' καταχωρήσεις',
		'edit'			=> 'επεξεργασία',
		'add_entry'		=> 'Προσθήκη καταχώρησης',
		'no_entries'	=> 'Καμία καταχώρηση'
	
	
	);

?>
