<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'Archív',
		'no_posts'		=> 'Žádné příspěvky',
	
	);

?>
