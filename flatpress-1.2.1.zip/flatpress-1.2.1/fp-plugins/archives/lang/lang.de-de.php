<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'Archiv',
		'no_posts'		=> 'Keine Posts',
	
	);

?>
