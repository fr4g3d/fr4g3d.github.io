<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'Arquivo de posts',
		'no_posts'		=> 'Sem posts',
	
	);

?>
