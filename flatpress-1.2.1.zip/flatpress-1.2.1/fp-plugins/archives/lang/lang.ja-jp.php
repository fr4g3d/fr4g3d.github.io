<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'アーカイブ',
		'no_posts'		=> '記事がありません。',
	
	);

?>
