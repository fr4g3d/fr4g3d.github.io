<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'Αρχειοθέτηση',
		'no_posts'		=> 'Καμία δημοσίευση',
	
	);

?>
