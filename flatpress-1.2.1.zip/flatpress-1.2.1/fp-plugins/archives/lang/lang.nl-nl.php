<?php
	$lang['plugin']['archives'] = array(
		
		'subject'		=> 'Archieven',
		'no_posts'		=> 'Geen vermeldingen',
	
	);

?>
