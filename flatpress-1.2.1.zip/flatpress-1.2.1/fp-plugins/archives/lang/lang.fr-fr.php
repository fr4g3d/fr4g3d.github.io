<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'Archives',
		'no_posts'		=> 'Pas de publications',
	
	);

?>
