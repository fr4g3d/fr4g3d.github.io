<?php
	$lang['plugin']['archives'] = array(
		
		'subject'		=> 'Archivos',
		'no_posts'		=> 'No hay publicaciones',
	
	);

?>
