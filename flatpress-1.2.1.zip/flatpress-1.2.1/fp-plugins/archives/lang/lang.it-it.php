<?php
	$lang['plugin']['archives'] = array(
		
		'subject'			=> 'Archivi',
		'no_posts'		=> 'Nessun articolo',
	
	);

?>
