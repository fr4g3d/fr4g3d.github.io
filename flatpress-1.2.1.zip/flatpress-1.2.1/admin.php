<?php
	
	require_once 'defaults.php';	
	require_once (INCLUDES_DIR.'includes.php');
	
	require ADMIN_DIR . '/main.php'
	
?>
