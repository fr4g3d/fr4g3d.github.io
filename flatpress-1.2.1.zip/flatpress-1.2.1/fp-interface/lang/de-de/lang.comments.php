<?php
$lang ['comments'] ['mail'] = 'Hallo %toname%,

"%fromname%" %frommail% hat einen Kommentar zu dem Thema "%entrytitle%" geschrieben.

Der Link zum diesem Kommentar:
%commentlink%

Folgendes wurde als Kommentar geschrieben:
***************
%content%
***************

Automatisch generiert von,
%blogtitle%

';

?>
