<?php
	
	$langconf = array();
	$langconf['id'] = 'Deutsch (DE)';
	$langconf['locale'] = 'de-de';
	$langconf['charsets'][0] = 'utf-8';
	$langconf['charsets'][1] = 'iso-8859-15';

?>
