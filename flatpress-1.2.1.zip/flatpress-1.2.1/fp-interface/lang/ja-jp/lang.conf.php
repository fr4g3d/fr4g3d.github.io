<?php
	
	$langconf = array();
	$langconf['id'] = 'Japanese (JP)';
	$langconf['locale'] = 'ja-jp';
	$langconf['charsets'][0] = 'utf-8';
	$langconf['charsets'][1] = 'iso-8859-15';

?>
