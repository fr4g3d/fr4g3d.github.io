<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'アップローダー',
		'descr'		=> 'アップロードしたいファイルを1つ以上指定してください。',
		'fset1'		=> 'ファイル指定',
		'fset2'		=> 'アップロード',
		'submit'	=> 'アップロードを開始する',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'ファイルのアップロードが完了しました。',
		-1	=> 'アップロードができませんでした。',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> '一覧',
		'descr'		=> 'アップロードしたいファイルを1つ以上指定してください。',
		'fset1'		=> 'ファイル指定',
		'submit'	=> 'アップロードする',

	);

	
?>
