<?php
$lang ['comments'] ['mail'] = '%toname% さま,

"%fromname%" %frommail% さんが、次の記事にコメントを書きました。

題名:
%entrytitle%

コメントへの直リンクurl:
%commentlink%

書かれたコメント:
***************
%content%
***************

以上,
%blogtitle%

';

?>
