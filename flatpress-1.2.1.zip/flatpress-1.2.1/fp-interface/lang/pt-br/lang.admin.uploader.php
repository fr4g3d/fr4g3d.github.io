<?php
//Terminado 15 de fevereiro de 2020.

	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'Carregador',
		'descr'		=> 'Escolha um ou mais arquivos para carregar.',
		'fset1'		=> 'Seletor de arquivos',
		'fset2'		=> 'Carregar',
		'submit'	=> 'Carregar',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'Arquivo(s) enviado(s)',
		-1	=> 'Ocorreu um erro ao tentar carregar.',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> 'Procure',
		'descr'		=> 'Escolha um ou mais arquivos para carregar.',
		'fset1'		=> 'Seletor de arquivos',
		'submit'	=> 'Carregar',

	);

	
?>
