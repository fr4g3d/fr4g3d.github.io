<?php
// Terminado 15 de fevereiro de 2020.
$lang ['comments'] ['mail'] = 'Querido(a) %toname%,

"%fromname%" %frommail% acabou de publicar um comentário na entrada intitulada "%entrytitle%".

Este é o link os comentários do seu post:
%commentlink%

Aqui está o comentário que acabou de ser postado:
***************
%content%
***************

Um abraço,
%blogtitle%

';

?>
