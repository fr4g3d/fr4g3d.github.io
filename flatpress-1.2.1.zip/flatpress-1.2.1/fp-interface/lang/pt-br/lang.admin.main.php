<?php
//Terminado 15 de fevereiro de 2020.

	$lang['admin']['panel']['main'] = 'Principal';
	
	$lang['admin']['main']['default'] = array(
		'head'		=> 'Bem-vindo ao painel de controle!',
		'descr'		=> 'Selecione uma ação.',
		
		'op1'		=> 'Novo post',
		'op1d'		=> 'Adicione um novo post.',
		'op2'		=> 'Posts',
		'op2d'		=> 'Mostre e administre todos os posts.',
		'op3'		=> 'Widgets',
		'op3d'		=> 'Administre sidebar, bottombar and topbar widgets.',
		'op4'		=> 'Plugins',
		'op4d'		=> 'Instale, ative, desative plugins',
		'op5'		=> 'Configuração',
		'op5d'		=> 'Personalize seu Flatpress',
		'op6'		=> 'Manutenção',
		'op6d'		=> 'Limpe e restaure o flatpress.',
		
	);
?>
