<?php
	
	$langconf = array();
	$langconf['id'] = 'Ελληνικά (GR)';
	$langconf['locale'] = 'el-gr';
	$langconf['charsets'][0] = 'utf-8';
	$langconf['charsets'][1] = 'iso-8859-7';

?>
