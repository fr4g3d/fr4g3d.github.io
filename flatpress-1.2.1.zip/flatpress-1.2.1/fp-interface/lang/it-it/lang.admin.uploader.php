<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'Caricatore',
		'descr'		=> 'Seleziona uno o più file da caricare.',
		'fset1'		=> 'Seleziona File',
		'fset2'		=> 'Carica',
		'submit'	=> 'Carica',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'File caricato(i)',
		-1	=> 'Si è verificato un errore durante il caricamento.',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> 'Sfoglia',
		'descr'		=> 'Seleziona uno o più file da caricare.',
		'fset1'		=> 'Seleziona File',
		'submit'	=> 'Carica',

	);

	
?>
