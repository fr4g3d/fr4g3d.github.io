<?php
	
	$langconf = array();
	$langconf['id'] = 'Italian (IT)';
	$langconf['locale'] = 'it-it';
	$langconf['charsets'][0] = 'utf-8';
	$langconf['charsets'][1] = 'iso-8859-15';

?>
