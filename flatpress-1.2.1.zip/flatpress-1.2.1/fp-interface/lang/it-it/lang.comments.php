<?php
$lang ['comments'] ['mail'] = 'Ciao %toname%,

"%fromname%" %frommail% ha inserito un commento all\'articolo intitolato "%entrytitle%".

Questo è il link al commento del tuo articolo:
%commentlink%

Questo è il commento che è stato appena postato:
***************
%content%
***************

Saluti,
%blogtitle%

';

?>
