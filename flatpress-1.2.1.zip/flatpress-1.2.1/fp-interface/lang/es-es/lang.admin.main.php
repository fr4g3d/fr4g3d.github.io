<?php

	$lang['admin']['panel']['main'] = 'Principal';
	
	$lang['admin']['main']['default'] = array(
		'head'		=> '¡Bienvenido al panel de control!',
		'descr'		=> 'Seleccione una acción',
		
		'op1'		=> 'Nueva entrada',
		'op1d'		=> 'Agregar una nueva entrada',
		'op2'		=> 'Entradas',
		'op2d'		=> 'Mostrar y administrar todas las entradas',
		'op3'		=> 'Widgets',
		'op3d'		=> 'Administrar la barra lateral, barra de abajo y de arriba de los widgets',
		'op4'		=> 'Plugins',
		'op4d'		=> 'Instalar, habilitar, deshabilitar plugins',
		'op5'		=> 'Configuración',
		'op5d'		=> 'Personalice su flatpress',
		'op6'		=> 'Mantención',
		'op6d'		=> 'Limpiar y restablecer flatpress',
		
	);
?>
