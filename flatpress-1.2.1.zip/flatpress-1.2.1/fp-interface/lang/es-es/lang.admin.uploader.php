<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'Subir Archivos',
		'descr'		=> 'Elija uno o más archivos para subir.',
		'fset1'		=> 'Selector de archivos',
		'fset2'		=> 'Subir',
		'submit'	=> 'Subir',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'Archivo(s) subido(s)',
		-1	=> 'Se produjo un error al intentar subir archivo(s).',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> 'Navegar',
		'descr'		=> 'Elija uno o más archivos para subir.',
		'fset1'		=> 'Selector de archivos',
		'submit'	=> 'Subir',

	);

	
?>
