<?php
	
	$langconf = array();
	$langconf['id'] = 'Español (ES)';
	$langconf['locale'] = 'es-es';
	$langconf['charsets'][0] = 'utf-8';
	$langconf['charsets'][1] = 'iso-8859-15';

?>
