<?php
$lang ['comments'] ['mail'] = 'Estimado %toname%,

"%fromname%" %frommail% acaba de publicar un comentario en la entrada titulada "%entrytitle%".

Este es el enlace de comentarios a su entrada:
%commentlink%

Aquí está el comentario que se acaba de publicar:
***************
%content%
***************

Todo lo mejor,
%blogtitle%

';

?>
