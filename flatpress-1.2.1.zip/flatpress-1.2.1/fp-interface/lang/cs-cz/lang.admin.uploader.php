<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'Nahrání souborů',
		'descr'		=> 'Vybrat jeden nebo více souborů k nahrání.',
		'fset1'		=> 'Výběr souborů',
		'fset2'		=> 'Nahrát',
		'submit'	=> 'Nahrát',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'Soubor(y) nahraný(é)',
		-1	=> 'Při pokusu nahrát soubor(y) nastala chyba.',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> 'Procházet',
		'descr'		=> 'Vybrat jeden nebo více souborů k nahrání.',
		'fset1'		=> 'Výběr souborů',
		'submit'	=> 'Nahrát',

	);

	
?>
