<?php
$lang ['comments'] ['mail'] = '"%fromname%" %frommail% přidal komentář k příspěvku "%entrytitle%".

Zde je odkaz na Váš příspěvek:
%commentlink%

Zde je komentář, který byl vložen:
%content%

S pozdravem %blogtitle%

';

?>
