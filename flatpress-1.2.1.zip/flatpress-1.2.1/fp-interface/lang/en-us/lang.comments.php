<?php
$lang ['comments'] ['mail'] = 'Dear %toname%,

"%fromname%" %frommail% has just posted a comment to the entry entitled "%entrytitle%".

This is the commentlink to your entry:
%commentlink%

Here is the comment that has just been posted:
***************
%content%
***************

All the best,
%blogtitle%

';

?>
