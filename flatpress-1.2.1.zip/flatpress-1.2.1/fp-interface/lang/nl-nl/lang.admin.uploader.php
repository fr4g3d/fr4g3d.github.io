<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'Oploaden',
		'descr'		=> 'Kies een of meer files voor uploaden.',
		'fset1'		=> 'File kiezer',
		'fset2'		=> 'Oploaden',
		'submit'	=> 'Oploaden',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'File(s) opgeladen',
		-1	=> 'Er is een fout opgetreden tijdens het uploaden.',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> 'Bladeren',
		'descr'		=> 'Kies een of meer files voor uploaden.',
		'fset1'		=> 'File kiezer',
		'submit'	=> 'Uploaden',

	);

	
?>
