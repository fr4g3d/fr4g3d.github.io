<?php
$lang ['comments'] ['mail'] = 'Beste %toname%,

"%fromname%" %frommail% heeft een commentaar geplaatst op de volgende post met als titel "%entrytitle%".

Dit het commentaar link naar je blog:
%commentlink%

Hier is het commentaar dat net is geplaatst:
***************
%content%
***************

Groeten,
%blogtitle%

';

?>
