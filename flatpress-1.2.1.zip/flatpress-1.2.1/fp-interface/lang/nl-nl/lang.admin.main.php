<?php
$lang ['admin'] ['panel'] ['main'] = 'Main';

$lang ['admin'] ['main'] ['default'] = array(
	'head' => 'Welkom in het administratie omgeving!',
	'descr' => 'Selecteer een actie',

	'op1' => 'Nieuwe vermelding',
	'op1d' => 'Een nieuwe vermelding toevoegen',
	'op2' => 'Vermeldingen',
	'op2d' => 'Toon en beheer alle vermeldingen',
	'op3' => 'Widgets',
	'op3d' => 'Beheer zijbalk, onderbalk en bovenbalk widgets',
	'op4' => 'Plugins',
	'op4d' => 'Plug-ins installeren, inschakelen, uitschakelen',
	'op5' => 'Configuratie',
	'op5d' => 'Bewerk je flatpress',
	'op6' => 'Onderhoud',
	'op6d' => 'Opschonen en herstel flatpress'
);
