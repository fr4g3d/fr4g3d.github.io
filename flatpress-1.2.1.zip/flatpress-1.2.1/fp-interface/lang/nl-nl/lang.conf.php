<?php
	
	$langconf = array();
	$langconf['id'] = 'Nederlands (NL)';
	$langconf['locale'] = 'nl-nl';
	$langconf['charsets'][0] = 'utf-8';
	$langconf['charsets'][1] = 'iso-8859-15';

?>
