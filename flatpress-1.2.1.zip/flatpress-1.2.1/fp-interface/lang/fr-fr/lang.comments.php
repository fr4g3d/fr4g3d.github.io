<?php
$lang ['comments'] ['mail'] = 'Bonjour %toname%,

"%fromname%" %frommail% a post&eacute; un commentaire sur un billet dont le titre est "%entrytitle%".

Lien direct vers le commentaire:
%commentlink%

Voici le commentaire post&eacute;:
***************
%content%
***************

Cordialement,
%blogtitle%

';

?>
