<?php


	$lang['admin']['uploader']['default'] = array(
		'head'		=> 'Transf&eacute;rer',
		'descr'		=> 'Choisissez un ou plusieurs fichiers &agrave; transf&eacute;rer.',
		'fset1'		=> 'Explorateur de fichiers',
		'fset2'		=> 'Transf&eacute;rer',
		'submit'	=> 'Transf&eacute;rer',

	);

	$lang['admin']['uploader']['default']['msgs'] = array(
		1	=> 'Fichier(s) transf&eacute;r&eacute;(s)',
		-1	=> 'Echec du transfert.',
	);
	
	
	
	$lang['admin']['uploader']['browse'] = array(
		'head'		=> 'Voir',
		'descr'		=> 'Choisissez un ou plusieurs fichiers &agrave; transf&eacute;rer.',
		'fset1'		=> 'Explorateur de fichiers',
		'submit'	=> 'Transf&eacute;rer',

	);

	
?>
