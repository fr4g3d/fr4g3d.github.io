<?php
	
	$langconf = array();
	$langconf['id'] = 'Fran&ccedil;ais (FR)';
	$langconf['locale'] = 'fr-fr';
	$langconf['charsets'][0] = 'utf-8';
	$langconf['charsets'][1] = 'iso-8859-15';

?>
