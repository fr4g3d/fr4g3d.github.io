flatpress-francais
==================
###Traduction française de FlatPress
http://flatpress.org
FlatPress (C)2006-2014 par Edoardo Vacchi sous licence GNU GPLv2.

###Traduction réalisée par:

FlatPress Communaute francophone
http://flatpress-fr.info

Marc Thibeault
http://marcthibeault.com

Version de la traduction: 0.1 Beta2 pour FlatPress versions 0.1010 - 0.1010.1 - 0.1010.2 - 1.0

Mise a jour: Si vous disposez d'une version précédente, écrasez simplement les anciens fichiers pour mettre à jour la traduction.

Version Beta de la traduction, certaines traductions sont encore à finaliser et à améliorer.

Aide:
Les fichiers sont à placer dans fp-interface/lang et dans fp-plugins. Pour les plugins, écrasez simplement les anciens fichiers. La structure des fichiers a été respectée!

###Historique:

####v0.1 BETA 2:

- correction/mise à jour de la traduction
- correction de l'encodage de certains caractères spéciaux en UTF-8.

####v0.1 BETA 1:

- première version publiée (traduction dossiers plugins + fp-interface/lang)

Dernière mise à jour du README: 28-08-2014
