<?php 
$OC_Version = array(23,0,12,2);
$OC_VersionString = '23.0.12';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '22.2' => true,
    '23.0' => true,
  ),
  'owncloud' => 
  array (
    '10.5' => true,
  ),
);
$OC_Build = '2022-12-08T13:07:59+00:00 4eca7512330808a958cbf00bbd9044ea77b3ab6b';
$vendor = 'nextcloud';
