# Product plan

* **Date:** …
* **Assignee:** …

## Overview 🛰️

### Problem to solve

Which problem are we trying to solve with this change?

### Proposal

Short description of our proposed solution.

### Timeline

* [ ] Week 1: …
* [ ] Week 2: …
* [ ] Week 3: …

---

## Research 🔮

### Related products

* Product from this company
* Some mobile app doing something similar
* …

### Screenshots

🖼

---

## Design 📐

### Specification

…

### Mockups & prototypes

…

---

## Engineering ⚙️

### Requirements

…

### Constraints

…
