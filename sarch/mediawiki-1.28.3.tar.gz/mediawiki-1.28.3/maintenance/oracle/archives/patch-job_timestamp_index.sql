define mw_prefix='{$wgDBprefix}';

CREATE INDEX &mw_prefix.job_i02 ON &mw_prefix.job (job_timestamp);

