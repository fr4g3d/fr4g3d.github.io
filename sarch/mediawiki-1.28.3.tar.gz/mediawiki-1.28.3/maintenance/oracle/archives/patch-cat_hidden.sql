define mw_prefix='{$wgDBprefix}';

ALTER TABLE &mw_prefix.category DROP COLUMN cat_hidden;

