ALTER TABLE /*$wgDBprefix*/archive
  ADD ar_content_model varbinary(32) DEFAULT NULL;
