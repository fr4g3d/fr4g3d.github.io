-- Extra image exif metadata, added for 1.5 but quickly removed.

ALTER TABLE /*$wgDBprefix*/image DROP img_exif;
