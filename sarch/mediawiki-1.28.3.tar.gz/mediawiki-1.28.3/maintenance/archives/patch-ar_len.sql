ALTER TABLE /*$wgDBprefix*/archive
  ADD ar_len INT UNSIGNED;

