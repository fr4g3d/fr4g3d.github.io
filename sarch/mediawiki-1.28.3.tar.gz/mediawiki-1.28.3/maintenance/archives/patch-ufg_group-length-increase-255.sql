ALTER TABLE /*_*/user_former_groups
	MODIFY COLUMN ufg_group varbinary(255) NOT NULL default '';
