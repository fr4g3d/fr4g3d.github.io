DROP INDEX /*i*/oi_name_archive_name ON /*_*/oldimage;
