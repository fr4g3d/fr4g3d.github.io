#!/bin/bash

# This shell script is PUBLIC DOMAIN. You may do whatever you want with it.

TOGGLE=$HOME/.toggle_touchpad

if [ -z "$1" ]
  then
    echo "" #"No argument supplied"
  else
sleep 3s
if [ ! -e $TOGGLE ]; then
	xinput disable 14
	touch $TOGGLE
else
	xinput  enable 14
	rm $TOGGLE
fi

fi

if [ ! -e $TOGGLE ]; then
    
    xinput disable 14
    touch $TOGGLE
    notify-send -c device -t 2800 -u low -i mouse --icon=/usr/share/icons/HighContrast/256x256/status/touchpad-disabled.png "TouchPad" "[X] Trackpad DISABLED"
    
else
    
    xinput  enable 14
    rm $TOGGLE
    notify-send -c device -t 2800 -u low -i mouse --icon=/usr/share/icons/HighContrast/256x256/devices/input-touchpad.png "TouchPad" "[√] Trackpad ENABLED"
    
fi
