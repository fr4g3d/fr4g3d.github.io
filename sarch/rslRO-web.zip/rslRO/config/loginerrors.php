<?php
return array(
	0 => 'Unexpected Error',
	1 => 'Invalid Server',
	2 => 'Invalid Credentials',
	3 => 'Temporarily Banned',
	4 => 'Permanently Banned',
	5 => 'IP Banned',
	6 => 'Invalid Security Code',
	7 => 'Pending Confirmation'
)
?>
