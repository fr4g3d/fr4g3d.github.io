<?php
return array(
	18   => 'Alchemist',
	4019 => 'Creator',
	4041 => 'Baby Alchemist',
	4071 => 'Genetic',
	4078 => 'Genetic+',
	4107 => 'Baby Genetic'
)
?>
