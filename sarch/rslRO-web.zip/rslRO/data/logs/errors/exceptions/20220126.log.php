<?php exit('Forbidden'); ?>
[2022-01-26 11:21:20] (Flux_Error) Exception Flux_Error: Critical MySQL error in Installer/Updater: Invalid default value for 'reg_date'
[2022-01-26 11:21:20] (Flux_Error) **TRACE** #0 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Installer\Schema.php(155): Flux_Installer_Schema->install(20080928225124)
[2022-01-26 11:21:20] (Flux_Error) **TRACE** #1 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Installer.php(69): Flux_Installer_Schema->update()
[2022-01-26 11:21:20] (Flux_Error) **TRACE** #2 D:\X.UserZ\Documents\GitHub\www\FluxCP\modules\install\index.php(31): Flux_Installer->updateAll()
[2022-01-26 11:21:20] (Flux_Error) **TRACE** #3 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Template.php(337): include('D:\\X.UserZ\\Docu...')
[2022-01-26 11:21:20] (Flux_Error) **TRACE** #4 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Dispatcher.php(168): Flux_Template->render()
[2022-01-26 11:21:20] (Flux_Error) **TRACE** #5 D:\X.UserZ\Documents\GitHub\www\FluxCP\index.php(171): Flux_Dispatcher->dispatch(Array)
[2022-01-26 11:21:20] (Flux_Error) **TRACE** #6 {main}
[2022-01-26 11:24:59] (Flux_Error) Exception Flux_Error: Critical MySQL error in Installer/Updater: Invalid default value for 'reg_date'
[2022-01-26 11:24:59] (Flux_Error) **TRACE** #0 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Installer\Schema.php(155): Flux_Installer_Schema->install(20080928225124)
[2022-01-26 11:24:59] (Flux_Error) **TRACE** #1 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Installer.php(69): Flux_Installer_Schema->update()
[2022-01-26 11:24:59] (Flux_Error) **TRACE** #2 D:\X.UserZ\Documents\GitHub\www\FluxCP\modules\install\index.php(31): Flux_Installer->updateAll()
[2022-01-26 11:24:59] (Flux_Error) **TRACE** #3 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Template.php(337): include('D:\\X.UserZ\\Docu...')
[2022-01-26 11:24:59] (Flux_Error) **TRACE** #4 D:\X.UserZ\Documents\GitHub\www\FluxCP\lib\Flux\Dispatcher.php(168): Flux_Template->render()
[2022-01-26 11:24:59] (Flux_Error) **TRACE** #5 D:\X.UserZ\Documents\GitHub\www\FluxCP\index.php(171): Flux_Dispatcher->dispatch(Array)
[2022-01-26 11:24:59] (Flux_Error) **TRACE** #6 {main}
