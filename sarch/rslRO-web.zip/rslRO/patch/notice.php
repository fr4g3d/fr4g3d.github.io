<!DOCTYPE html>
<html>
<head>
<title>rslRO - Notice</title>
</head>
<link rel="stylesheet" href="style.css" type="text/css">
<body scroll="no">
	<tr valign="top">
		<td>
		<div style="height:200px; width:100%;">
		<table border="0" width="100%" cellspacing="2" cellpadding="2">
			<tr>
				<td width="100%"><span class="header">Welcome to RSL Ragnarok Online!</span>
					<div class="content">
						<ul>
							<li>Register</li>
							<li>Download</li>
							<li>Play</li>
							<li>Enjoy</li>
						</ul>
					</div>
				</td>
			</tr>
		</table>
		</div>
		</td>
	</tr>
</body>
</html>
