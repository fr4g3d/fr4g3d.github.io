<!DOCTYPE html>
<html>
<head>
<title>rslRO - Status</title>
</head>
<link rel="stylesheet" href="style.css" type="text/css">
<body scroll="no">
<?php
//error_reporting (null);
require_once("config.inc.php");
//WebServer
$fp = @fsockopen ("$hostip", $webport, $limit);
if (!$fp) { $websrv="<font color=ff0000>Offline</font>"; } else { $websrv="<font color=00ff00>Online</font>"; }
//LoginServer
$fp = @fsockopen ("$hostip", $loginport, $limit);
if (!$fp) { $loginsrv="<font color=ff0000>Offline</font>"; } else { $loginsrv="<font color=00ff00>Online</font>"; }
//CharServer
$fp = @fsockopen ("$hostip", $charport, $limit);
if (!$fp) { $charsrv="<font color=ff0000>Offline</font>"; } else { $charsrv="<font color=00ff00>Online</font>"; }
//MapServer
$fp = fsockopen ("$hostip", $mapport, $limit);
if (!$fp) { $mapsrv="<font color=ff0000>Offline</font>"; } else { $mapsrv="<font color=00ff00>Online</font>"; }
// Remap Vars
$stsWeb = $websrv;
$stsLogin = $loginsrv;
$stsChar = $charsrv;
$stsMap = $mapsrv;
?>
<div class="status"><font color=orange>rslRO-Status:</font>
[web:<?php echo $stsWeb; ?>] 
[login:<?php echo $stsLogin; ?>] 
[char:<?php echo $stsChar; ?>] 
[map:<?php echo $stsMap; ?>] </div>
<script>
setInterval('window.location.reload()', 11000);
</script>
</body>
</html>
