<?php
// Config File:
// for Host/IP/DNS, Port and timeout.
$hostip="ro.rsl.my.id";	// The IP/DNS Adress
$webport="88";		// WebServer Port
$loginport="6900";	// LoginServer Port
$charport="6121";	// CharacterServer Port
$mapport="5121";	// MapServer Port
$tl="0.5";		// Timeout Limit
?>
