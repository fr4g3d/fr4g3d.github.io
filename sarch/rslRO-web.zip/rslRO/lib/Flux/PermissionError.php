<?php
require_once 'Flux/Error.php';

class Flux_PermissionError extends Flux_Error {
	
}
?>
