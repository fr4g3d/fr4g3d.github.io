<?php
if (!defined('FLUX_ROOT')) exit;

header('HTTP/1.1 404 Not Found');
$title = Flux::message('PageNotFoundTitle');
?>
