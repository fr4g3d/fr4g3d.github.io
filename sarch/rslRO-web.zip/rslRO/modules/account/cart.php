<?php
if (!defined('FLUX_ROOT')) exit;
$this->redirect($this->url('purchase', 'cart'));
?>
