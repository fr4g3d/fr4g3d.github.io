---
name: Feature request
about: Suggest an idea for this project

---

## Description
A short description of your idea

## Why it should be implemented
Who it would benefit, ...

## Optional: implementation suggestions
If you have experience in this field, feel free to give us suggestions

## Optional: screenshots
Add some screenshots, mockups, ... if they help clarify what you want
