{{blog|./pages/AjaxCMS_Blog}}

