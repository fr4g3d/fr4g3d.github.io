This is a file with a layout inserted into a page without a layout.  The inserted file is in a folder that has a layout.html file.  The layout.html file uses the filelist helper to display a list of files in the sidebar.<hr>

{{insert | layout.md }}
