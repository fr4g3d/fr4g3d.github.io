# AjaxCMS
Javascript based front-end CMS with static file backend.

Demo and documentation at http://ajaxcms.org

Contact brandon.hoult@softwyre.com for more information.
