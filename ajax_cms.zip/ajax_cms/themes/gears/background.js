/* (c) 2016 Softwyre Inc / Brandon Hoult. for More Information email: brandon.hoult@softwyre.com */

$('#background-div').append("<div id='wrapper' style='display:none'></div>");
$('#background-div #wrapper').append("<img id='gear_1' class='large' src='themes/gears/images/gear1.svg'>");
$('#background-div #wrapper').append("<img id='gear_2' class='small' src='themes/gears/images/gear2.svg'>");
$('#background-div #wrapper').append("<img id='gear_3' class='large' src='themes/gears/images/gear1.svg'>");
$('#background-div #wrapper').append("<img id='gear_4' class='large' src='themes/gears/images/gear1.svg'>");
$('#background-div #wrapper').append("<img id='gear_5' class='small' src='themes/gears/images/gear2.svg'>");
$('#background-div #wrapper').append("<img id='gear_6' class='large' src='themes/gears/images/gear1.svg'>");
$('#background-div #wrapper').fadeIn(1000);